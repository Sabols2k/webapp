<?php 

define('URLAdmin', 'http://localhost:8080/Web_App/Quite_Luxury/admin/');
define('URL_Layout', 'http://localhost:8080/Web_App/Quite_Luxury/Home/');
define('URL', 'http://localhost:8080/Web_App/Quite_Luxury/');
define('imgAccount', 'http://localhost:8080/Web_App/Quite_Luxury/mvc/Assets/admin/img/account/');
define('imgRoomtype', 'http://localhost:8080/Web_App/Quite_Luxury/mvc/Assets/admin/img/roomtype/');
define('imgAdmin', './mvc/Assets/admin/img/');
?>

