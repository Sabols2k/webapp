<?php
session_start();
require_once "./mvc/Bridge.php";
require_once("request.php");
$myApp = new App();
?>