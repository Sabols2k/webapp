<div class="topbar">
    <div class="container">
        <div class="welcome-mssg">
        Welcome to Quite Luxury.
        </div>
        <div class="top-right-menu">
        <ul class="top-menu">
            <li class="d-none d-md-inline">
            <a href="#">
                <i class="fa fa-phone"></i>076 922 0162
            </a>
            </li>
            <li class="d-none d-md-inline">
            <a href="#">
                <i class="fa fa-envelope-o "></i>hotelquiteluxury@gmail.com</a>
            </li>
        </ul>
        </div>
    </div>
</div>