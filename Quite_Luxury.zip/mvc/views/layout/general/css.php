    <!-- ========== FAVICON ========== -->
    <link rel="icon" href="<?php echo URL ."mvc/Assets/images/favicon-logo.png"?>">
    <!-- ========== STYLESHEETS ========== -->
    <link rel="stylesheet" href="<?php echo URL ."mvc/Assets/css/bootstrap.min.css" ?>">
    <link rel="stylesheet" href="<?php echo URL ."mvc/Assets/css/bootstrap-select.min.css" ?>">
    <link rel="stylesheet" href="<?php echo URL ."mvc/Assets/css/jquery.mmenu.css" ?>">
    <link rel="stylesheet" href="<?php echo URL ."mvc/Assets/revolution/css/layers.css" ?>">
    <link rel="stylesheet" href="<?php echo URL ."mvc/Assets/revolution/css/settings.css" ?>">
    <link rel="stylesheet" href="<?php echo URL ."mvc/Assets/revolution/css/navigation.css" ?>">
    <link rel="stylesheet" href="<?php echo URL ."mvc/Assets/css/animate.min.css" ?>">
    <link rel="stylesheet" href="<?php echo URL ."mvc/Assets/css/owl.carousel.min.css" ?>">
    <link rel="stylesheet" href="<?php echo URL ."mvc/Assets/css/daterangepicker.css" ?>">
    <link rel="stylesheet" href="<?php echo URL ."mvc/Assets/css/magnific-popup.css" ?>">
    <link rel="stylesheet" href="<?php echo URL ."mvc/Assets/css/style.css" ?>">
    <link rel="stylesheet" href="<?php echo URL ."mvc/Assets/css/responsive.css" ?>">
    <!-- ========== ICON FONTS ========== -->
    <link href="<?php echo URL ."mvc/Assets/fonts/font-awesome.min.css"?>" rel="stylesheet">
    <link href="<?php echo URL ."mvc/Assets/fonts/flaticon.css"?>" rel="stylesheet">
    <!-- ========== GOOGLE FONTS ========== -->
    <link href="https://fonts.googleapis.com/css?family=Oswald:400,500,600,700%7CRoboto:100,300,400,400i,500,700" rel="stylesheet">