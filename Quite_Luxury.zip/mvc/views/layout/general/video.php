<section class="video np parallax gradient-overlay op6" data-src="<?php echo URL ."mvc/Assets/images/video.jpg"?>" data-parallax="scroll" data-speed="0.3" data-mirror-selector=".wrapper" data-z-index="0">
        <div class="inner gradient-overlay">
          <div class="container">
            <div class="video-popup">
              <a class="popup-vimeo" href="<?php echo URL ."mvc/Assets/https://www.youtube.com/watch?v=BDDfopejpwk"?>">
                <i class="fa fa-play"></i>
              </a>
            </div>
          </div>
        </div>
</section>