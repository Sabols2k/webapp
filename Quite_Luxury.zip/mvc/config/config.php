<?php 

define('URLAdmin', 'http://localhost:8080/Web_App/Quite_Luxury/admin/');
define('URL_Layout', 'http://localhost:8080/Web_App/Quite_Luxury/Home/');
define('URL', 'http://localhost:8080/Web_App/Quite_Luxury/');
define('imgAccount', 'http://localhost:8080/Web_App/Quite_Luxury/mvc/Assets/admin/img/account/');
define('imgRoomtype', 'http://localhost:8080/Web_App/Quite_Luxury/mvc/Assets/admin/img/roomtype/');
define('imgAdmin', 'http://localhost:8080/Web_App/Quite_Luxury/mvc/Assets/admin/img/');

// define('URLAdmin', 'https://sabols2k.000webhostapp.com/admin/');
// define('URL_Layout', 'https://sabols2k.000webhostapp.com/Home/');
// define('URL', 'https://sabols2k.000webhostapp.com/');
// define('imgAccount', 'https://sabols2k.000webhostapp.com/mvc/Assets/admin/img/account/');
// define('imgRoomtype', 'https://sabols2k.000webhostapp.com/mvc/Assets/admin/img/roomtype/');
// define('imgAdmin', 'https://sabols2k.000webhostapp.com/mvc/Assets/admin/img/');
?>

